using Firebase;
using Firebase.Firestore;
using Firebase.Extensions;
using UnityEngine;
using System;
using System.Threading.Tasks;

public class CloudSaveService : MonoBehaviour
{
    public static CloudSaveService Instance { get; private set; }
    
    private FirebaseFirestore _db;
    private string _currentUserId;
    private bool _isInitialized;

    [FirestoreData]
    public struct PlayerData
    {
        [FirestoreProperty] public int Coins { get; set; }
        [FirestoreProperty] public int XP { get; set; }
        [FirestoreProperty] public string Name { get; set; }
        [FirestoreProperty] public int Wins { get; set; }
    }

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
        DontDestroyOnLoad(gameObject);
        
        InitializeFirebase();
    }

    private void InitializeFirebase()
    {
        FirebaseApp.CheckAndFixDependenciesAsync().ContinueWithOnMainThread(task => {
            var dependencyStatus = task.Result;
            if (dependencyStatus == DependencyStatus.Available)
            {
                _db = FirebaseFirestore.DefaultInstance;
                _isInitialized = true;
                Debug.Log("Firebase Firestore Initialized");
            }
            else
            {
                Debug.LogError($"Could not resolve Firebase dependencies: {dependencyStatus}");
            }
        });
    }

    public void SetUser(string userId) => _currentUserId = userId;

    public async Task SaveProgress(PlayerData data)
    {
        if (!_isInitialized || string.IsNullOrEmpty(_currentUserId)) return;

        DocumentReference docRef = _db.Collection("players").Document(_currentUserId);
        try
        {
            await docRef.SetAsync(data, SetOptions.MergeAll);
            Debug.Log("Cloud Save Successful");
        }
        catch (Exception e)
        {
            Debug.LogError($"Cloud Save Failed: {e.Message}");
        }
    }

    public async Task<PlayerData?> LoadProgress()
    {
        if (!_isInitialized || string.IsNullOrEmpty(_currentUserId)) return null;

        DocumentReference docRef = _db.Collection("players").Document(_currentUserId);
        DocumentSnapshot snapshot = await docRef.GetSnapshotAsync();

        if (snapshot.Exists)
        {
            return snapshot.ConvertTo<PlayerData>();
        }
        return null;
    }
}
