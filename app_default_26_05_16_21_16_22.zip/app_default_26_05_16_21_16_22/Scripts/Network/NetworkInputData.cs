using Fusion;
using UnityEngine;

/// <summary>
/// This struct defines the data sent from clients to the server every tick.
/// Using NetworkButtons is more bandwidth-efficient than booleans.
/// </summary>
public struct NetworkInputData : INetworkInput
{
    public const byte BUTTON_PUNCH = 0x01;
    public const byte BUTTON_KICK = 0x02;
    public const byte BUTTON_BLOCK = 0x04;
    public const byte BUTTON_JUMP = 0x08;

    public Vector3 direction;
    public NetworkButtons buttons;

    public bool IsDown(byte button) => buttons.IsSet(button);
}
