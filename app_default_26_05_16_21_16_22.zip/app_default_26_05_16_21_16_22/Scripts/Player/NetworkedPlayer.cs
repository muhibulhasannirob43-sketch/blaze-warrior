using Fusion;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class NetworkedPlayer : NetworkBehaviour
{
    [Header("Stats")]
    [Networked, OnChangedRender(nameof(OnHealthChanged))] 
    public float Health { get; set; } = 100f;
    
    [Networked] public float Stamina { get; set; } = 100f;

    [Header("Movement")]
    public float MoveSpeed = 5f;
    public float RotationSpeed = 10f;

    private CharacterController _controller;
    private Animator _animator;
    private TickTimer _attackCooldown;

    public override void Spawned()
    {
        _controller = GetComponent<CharacterController>();
        _animator = GetComponentInChildren<Animator>();
    }

    public override void FixedUpdateNetwork()
    {
        if (GetInput(out NetworkInputData data))
        {
            // Handle Movement
            Vector3 move = data.direction.normalized * MoveSpeed * Runner.DeltaTime;
            _controller.Move(move);

            if (move.magnitude > 0.1f)
            {
                Quaternion lookRotation = Quaternion.LookRotation(move);
                transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, RotationSpeed * Runner.DeltaTime);
                _animator.SetFloat("Speed", move.magnitude);
            }
            else
            {
                _animator.SetFloat("Speed", 0);
            }

            // Handle Combat Inputs
            if (_attackCooldown.ExpiredOrNotRunning(Runner))
            {
                if (data.IsDown(NetworkInputData.BUTTON_PUNCH))
                {
                    RPC_RequestAttack("Punch", 10f);
                    _attackCooldown = TickTimer.CreateFromSeconds(Runner, 0.5f);
                }
                else if (data.IsDown(NetworkInputData.BUTTON_KICK))
                {
                    RPC_RequestAttack("Kick", 15f);
                    _attackCooldown = TickTimer.CreateFromSeconds(Runner, 0.8f);
                }
            }
        }
    }

    [Rpc(RpcSources.InputAuthority, RpcTargets.StateAuthority)]
    public void RPC_RequestAttack(string type, float staminaCost)
    {
        // Server-side validation
        if (Stamina >= staminaCost)
        {
            Stamina -= staminaCost;
            _animator.SetTrigger(type);
            
            // Logic for Hitbox Detection (Simplified)
            CheckHit(type);
        }
    }

    private void CheckHit(string attackType)
    {
        // Spherical overlap check for damage
        Collider[] hitColliders = Physics.OverlapSphere(transform.position + transform.forward, 1.5f);
        foreach (var hit in hitColliders)
        {
            if (hit.gameObject != gameObject && hit.TryGetComponent<NetworkedPlayer>(out var enemy))
            {
                enemy.TakeDamage(attackType == "Punch" ? 5f : 10f);
            }
        }
    }

    public void TakeDamage(float amount)
    {
        if (Object.HasStateAuthority)
        {
            Health -= amount;
            if (Health <= 0) Respawn();
        }
    }

    private void Respawn()
    {
        Health = 100f;
        Stamina = 100f;
        transform.position = new Vector3(Random.Range(-5, 5), 1, 0);
    }

    static void OnHealthChanged(Changed<NetworkedPlayer> changed)
    {
        // Update UI locally when health changes
        Debug.Log($"Player Health: {changed.Behaviour.Health}");
    }
}
