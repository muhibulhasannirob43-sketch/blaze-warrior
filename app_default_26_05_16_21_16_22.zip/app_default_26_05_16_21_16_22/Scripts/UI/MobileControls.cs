using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// Static helper for reading mobile UI inputs.
/// In a real scenario, use a Virtual Joystick asset or Input System Package.
/// </summary>
public class MobileControls : MonoBehaviour
{
    public static bool IsPunching { get; private set; }
    public static bool IsKicking { get; private set; }

    public void OnPunchDown() => IsPunching = true;
    public void OnPunchUp() => IsPunching = false;
    
    public void OnKickDown() => IsKicking = true;
    public void OnKickUp() => IsKicking = false;

    // UI helper method for Buttons
    public void SetPunch(bool state) => IsPunching = state;
    public void SetKick(bool state) => IsKicking = state;
}
