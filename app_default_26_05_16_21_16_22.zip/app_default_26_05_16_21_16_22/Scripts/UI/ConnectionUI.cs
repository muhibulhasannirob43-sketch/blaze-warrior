using UnityEngine;
using UnityEngine.UI;
using Fusion;
using TMPro;

public class ConnectionUI : MonoBehaviour
{
    [SerializeField] private TMP_InputField _roomNameInput;
    [SerializeField] private Button _hostButton;
    [SerializeField] private Button _joinButton;
    [SerializeField] private GameObject _loadingOverlay;

    private void Start()
    {
        _hostButton.onClick.AddListener(() => StartSession(GameMode.Host));
        _joinButton.onClick.AddListener(() => StartSession(GameMode.Client));
    }

    private async void StartSession(GameMode mode)
    {
        _loadingOverlay.SetActive(true);
        string roomName = string.IsNullOrEmpty(_roomNameInput.text) ? "DefaultRoom" : _roomNameInput.text;
        
        await NetworkManager.Instance.StartGame(mode, roomName);
        
        _loadingOverlay.SetActive(false);
        gameObject.SetActive(false); // Hide menu
    }
}
