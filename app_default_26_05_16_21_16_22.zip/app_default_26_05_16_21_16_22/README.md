# Iron Fist Online - Core Implementation

A production-ready 3D fighting game foundation using **Photon Fusion** for state-synchronized networking and **Firebase** for player progression.

## Features
- **High-Performance Networking**: Tick-based simulation with client-side prediction and server reconciliation via Photon Fusion.
- **Combat System**: Stamina-gated attacks (Punch/Kick) with RPC validation.
- **Cloud Persistence**: Automatic syncing of XP, Wins, and Currency to Firebase Firestore.
- **Cross-Platform Input**: Unified input handling for Keyboard and Mobile Touch.

## Prerequisites
- **Unity 2021.3 LTS** or higher.
- **Photon Fusion SDK**: [Download here](https://doc.photonengine.com/fusion/current/getting-started/sdk-download).
- **Firebase Unity SDK**: Specifically `FirebaseFirestore.unitypackage`.
- **Photon App ID**: Create a Fusion App ID at the [Photon Dashboard](https://dashboard.photonengine.com/).

## Installation & Setup

1.  **Unity Setup**:
    - Create a new 3D URP project.
    - Import the **Photon Fusion SDK** and **Firebase Firestore SDK**.
    - Run the Fusion Setup Wizard and paste your `App ID`.

2.  **Scene Preparation**:
    - Create an empty GameObject named `NetworkManager` and attach the `NetworkManager.cs` script.
    - Create a UI Canvas with `ConnectionUI.cs`, linking the InputField and Buttons.
    - Create a Player Prefab:
        - Add a `CharacterController` component.
        - Add a `NetworkObject` component.
        - Add the `NetworkedPlayer.cs` script.
        - Drag your 3D model as a child and link the `Animator`.
        - Drag this prefab into the `NetworkManager`'s `Player Prefab` slot.

3.  **Firebase Configuration**:
    - Create a project in the [Firebase Console](https://console.firebase.google.com/).
    - Add a Unity App and download the `google-services.json` (Android) or `GoogleService-Info.plist` (iOS).
    - Place the config file in your Unity `Assets` folder.
    - Enable **Cloud Firestore** in "Test Mode" for initial development.

4.  **Running the Game**:
    - Open the `Build Settings`, add your main scene.
    - Press **Play** in the editor to act as a Host.
    - Build a standalone version (Ctrl+B) to act as a Client.

## Project Structure
- `Scripts/Network/`: Fusion core logic and input definitions.
- `Scripts/Player/`: Movement, Combat logic, and Health synchronization.
- `Scripts/Cloud/`: Firebase Firestore integration for persistent data.
- `Scripts/UI/`: Menu systems and mobile control wrappers.

## Troubleshooting
- **Fusion Simulation Not Starting**: Ensure the `App ID` is valid and the `NetworkRunner` is active in the hierarchy.
- **Firebase Init Error**: Check that the `google-services.json` is in the root of the `Assets` folder and that the package name matches your Firebase project.
- **No Movement**: Ensure the `CharacterController` is not being fought by a `Rigidbody`. Fusion handles `CharacterController` best for fighting games.
